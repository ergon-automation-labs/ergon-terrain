{application,kcl,
             [{config_mtime,1773434311},
              {optional_applications,[]},
              {applications,[kernel,stdlib,elixir,ed25519,curve25519,salsa20,
                             poly1305]},
              {description,"A less savory pure Elixir NaCl (libsodium) crypto suite substitute\n"},
              {modules,['Elixir.Kcl','Elixir.Kcl.State']},
              {registered,[]},
              {vsn,"1.5.0"}]}.
